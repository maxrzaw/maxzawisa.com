﻿-----------Key Controls-------------
           Move : Arrow keys or WASD
       A Weapon : X
       B Weapon : Z
Rotate B Weapon : C
Special Ability : Space
 Invincibility  : 1
   Custom Level : 4